<?php
  include('koneksi.php'); //agar index terhubung dengan database, maka koneksi sebagai penghubung harus di include
  
?>
<!DOCTYPE html>
<html>
  <head>
    <title>Tambah SPP</title>
   
  </head>
<body>
  <?php
  include ('tampilan/header.php');
  include ('tambahkelas.php');
  include ('tampilan/footer.php');
?>
 